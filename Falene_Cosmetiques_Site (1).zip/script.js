let panier = JSON.parse(localStorage.getItem("panier")) || [];

function mettreAJourPanier() {
  const liste = document.getElementById("liste-panier");
  const totalSpan = document.getElementById("total");
  const nbItems = document.getElementById("nb-items");

  liste.innerHTML = "";
  let total = 0;

  panier.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = `${item.nom} - ${item.prix}€`;
    const btn = document.createElement("button");
    btn.textContent = "Retirer";
    btn.onclick = () => retirerDuPanier(index);
    li.appendChild(btn);
    liste.appendChild(li);
    total += item.prix;
  });

  totalSpan.textContent = total;
  nbItems.textContent = panier.length;
  localStorage.setItem("panier", JSON.stringify(panier));
}

function ajouterAuPanier(nom, prix) {
  panier.push({ nom, prix });
  mettreAJourPanier();
}

function retirerDuPanier(index) {
  panier.splice(index, 1);
  mettreAJourPanier();
}

function viderPanier() {
  panier = [];
  mettreAJourPanier();
}

window.onload = mettreAJourPanier;